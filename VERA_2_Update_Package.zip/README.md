# VERA 2.0 Update Package

Files:
- `VERA_2_PRODUCT_SPEC.md` — consolidated product and safety specification
- `IMPLEMENTATION_PROMPT.md` — prompt for a coding agent or developer
- `PUBLISH_TO_GITHUB_PAGES.md` — deployment instructions

Use the product specification as the source of truth. Do not publish claims of autonomous capabilities until the corresponding backend integrations are genuinely working.
