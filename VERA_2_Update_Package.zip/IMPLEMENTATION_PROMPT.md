# Implementation Prompt for VERA 2.0

Update the existing VERA website into a trauma-informed recovery coordinator. Preserve the existing visual identity unless a change is required for accessibility. The user experience must feel calm, uncluttered, protective, and human.

## Build these screens

1. Welcome and safety
2. What would help most right now?
3. Check-in frequency
4. Support-style preferences
5. One Thing dashboard
6. Consent and delegation center
7. Trusted Circle and three disclosure levels
8. Privacy guidance: what not to tell employers, partners, friends, and family
9. Digital Preservation / Freeze Before Changing
10. Unread Evidence Vault
11. My Story with immutable original entry plus versioned additions and corrections
12. Find Care intake: insurance image, ZIP code, preferences, urgency
13. VERA Is Handling / Waiting / Needs Your Decision / Nothing Urgent Tonight
14. Protective Break mode
15. Prototype limitations and emergency guidance

## Interaction rules

- Ask one consequential question per screen.
- Show the rationale beneath every recommendation.
- Obtain explicit approval before sensitive actions.
- Allow standing authorization only for low-risk administrative tasks.
- Never infer silence as consent.
- Never claim a task was sent, booked, called, or processed unless an integration confirms completion.
- Allow users to revoke consent at any time.
- Provide a prominent “Do not show me the contents” setting for preserved evidence.
- Preserve an audit trail for consent, files, messages, and narrative changes.
- Separate direct recollection, documentary fact, third-party report, inference, uncertainty, and disputed information.
- Use warm, plain language.
- Avoid dense menus and long checklists.
- Make the app keyboard accessible and responsive.

## Initial release behavior

Use local browser storage or a clearly labeled demonstration data layer for prototype state. Do not imply HIPAA compliance, attorney-client privilege, evidentiary chain-of-custody certification, autonomous calling, autonomous messaging, or secure clinical record storage unless those systems have actually been implemented and reviewed.

Create a configuration file for future integrations:

- email
- SMS/WhatsApp
- Google Calendar
- provider directories
- insurance verification
- secure file storage
- wearable data
- crisis and emergency routing

All integrations must default to disabled and display “Not connected” until configured.

Use the full product specification in `VERA_2_PRODUCT_SPEC.md` as the source of truth.
