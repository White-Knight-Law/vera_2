# Publish VERA through GitHub Pages

## Important repository issue

The public repository `ai-wklaw/vera_2` currently appears empty, while the live URL previously used is under `white-knight-law.github.io/vera_2/`. These are different GitHub owners. Confirm which organization owns the live Pages repository before uploading.

## Browser-only method

1. Sign in to GitHub.
2. Open the repository that is supposed to publish the live VERA site.
3. Confirm the owner shown at the top:
   - `white-knight-law/vera_2`, or
   - `ai-wklaw/vera_2`.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**, unless the site is built into `/docs`
6. Return to the **Code** tab.
7. Choose **Add file → Upload files**.
8. Upload the updated website files, including `index.html` and all CSS, JavaScript, and assets.
9. Add:
   - `VERA_2_PRODUCT_SPEC.md`
   - `IMPLEMENTATION_PROMPT.md`
10. Commit directly to `main`.
11. Open **Actions** and confirm the Pages deployment succeeds.
12. Open **Settings → Pages** to see the exact published URL.
13. Hard-refresh the site or open it in a private window.

## Git command method

Run these commands inside the correct local repository:

```bash
git status
git add .
git commit -m "Release VERA 2.0 trauma-informed orchestration update"
git push origin main
```

If the folder is not yet connected:

```bash
git init
git branch -M main
git remote add origin https://github.com/OWNER/vera_2.git
git add .
git commit -m "Initial VERA 2.0 release"
git push -u origin main
```

Replace `OWNER` with the organization that should host the site.

## Before publishing

Do not put API keys, private victim information, medical details, legal files, phone credentials, WhatsApp tokens, or service-account secrets into GitHub Pages. GitHub Pages is a public static host.

A production agentic VERA needs a separate secured backend for:

- authentication
- consent records
- encrypted storage
- messaging
- calendar access
- provider outreach
- audit logs
- health data
- safety escalation

The public Pages site should initially function as a carefully labeled prototype until that backend exists.
