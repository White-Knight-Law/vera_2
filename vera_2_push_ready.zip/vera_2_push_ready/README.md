# VERA

VERA is a browser-based guided electronic crime victim advocate for White Knight Law.

## Fastest deployment

1. Open `config.js`.
2. Add the approved WhatsApp Business number using digits only.
3. Upload every file in this folder to the root of the `vera_2` GitHub repository.
4. Commit the changes to `main`.
5. In GitHub, open **Settings > Pages** and select **Deploy from a branch**, branch `main`, folder `/ (root)`.

The public site should appear at:

`https://white-knight-law.github.io/vera_2/`

## Configure WhatsApp

Edit this line in `config.js`:

```js
whatsappNumber: "15165551234",
```

Use the full country code and number with digits only. Do not include `+`, spaces, dashes, or parentheses.

This enables a click-to-chat link. It does not create automated two-way WhatsApp messaging.

## Push with Git

From inside this folder:

```bash
git init
git branch -M main
git add .
git commit -m "Deploy VERA victim advocate messaging system"
git remote add origin https://github.com/ai-wklaw/vera_2.git
git push -u origin main --force-with-lease
```

If the repository is already cloned, copy these files into the repository folder and run:

```bash
git add .
git commit -m "Deploy VERA victim advocate messaging system"
git push origin main
```

## What works

- Guided one-question-at-a-time intake
- Immediate-danger screening
- Incident summary
- Timeline and evidence organization
- Local browser save and resume
- Downloadable handoff file
- Human-review request marker
- Quick exit and local-data deletion
- Mobile and keyboard-friendly interface
- Configurable WhatsApp click-to-chat

## Security limitation

GitHub Pages is static. It cannot securely receive WhatsApp webhooks, store private case files, authenticate staff, or notify an advocate.

Do not place Meta API tokens, application secrets, passwords, database credentials, or private information in this repository.

Automated WhatsApp conversations require a separate secure backend using the official Meta WhatsApp Cloud API.
