# Push VERA to GitHub

## Option A: Upload through GitHub

1. Go to `https://github.com/ai-wklaw/vera_2`.
2. Select **Add file > Upload files**.
3. Upload `index.html`, `config.js`, `.nojekyll`, `.gitignore`, `README.md`, and `DEPLOY.md`.
4. Choose **Commit directly to the main branch**.
5. Select **Commit changes**.

## Option B: Terminal

Unzip the package, open Terminal in the unzipped folder, and run:

```bash
git init
git branch -M main
git add .
git commit -m "Deploy VERA messaging system"
git remote add origin https://github.com/ai-wklaw/vera_2.git
git push -u origin main --force-with-lease
```

GitHub may ask you to sign in or use a personal access token.

## Verify GitHub Pages

Open repository **Settings > Pages** and confirm:

- Source: Deploy from a branch
- Branch: main
- Folder: / (root)

Then open:

`https://white-knight-law.github.io/vera_2/`
