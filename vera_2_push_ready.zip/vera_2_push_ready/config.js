/*
  VERA public configuration
  WhatsApp number format: country code + number, digits only.
  Example for a US number: 15165551234

  IMPORTANT:
  This file is public on GitHub Pages. Do not put API tokens, passwords,
  webhook secrets, database credentials, or private keys here.
*/
window.VERA_CONFIG = {
  whatsappNumber: "",
  humanReviewEndpoint: ""
};
