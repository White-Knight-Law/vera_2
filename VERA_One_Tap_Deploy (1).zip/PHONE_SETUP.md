# VERA One-Tap Deployment

This package adds a GitHub Actions workflow that publishes the repository to GitHub Pages:

- automatically whenever `main` changes; and
- manually through a **Run workflow** button.

## One-time setup from an iPhone

### 1. Put these files in the correct VERA repository

Upload:

- `.github/workflows/deploy-vera.yml`
- `.nojekyll`

The repository must also contain the actual website, including `index.html` in its root.

Because GitHub's mobile upload interface may not preserve nested folders easily, the most reliable phone method is:

1. Open the repository in Safari.
2. Request the desktop website if needed.
3. Choose **Add file → Create new file**.
4. In the filename field enter exactly:

   `.github/workflows/deploy-vera.yml`

5. Paste the workflow from this package.
6. Commit directly to `main`.
7. Create a second file named `.nojekyll` and leave it empty.

### 2. Enable GitHub Actions Pages

1. Open **Settings** in the repository.
2. Open **Pages**.
3. Under **Build and deployment**, set **Source** to **GitHub Actions**.
4. Open **Actions** and make sure workflows are allowed.

### 3. First deployment

1. Open **Actions**.
2. Select **Deploy VERA**.
3. Tap **Run workflow**.
4. Keep the branch as `main`.
5. Tap the green **Run workflow** button.

GitHub will publish the files currently stored in the repository.

## Every later deployment

If website code was changed and committed to `main`, deployment happens automatically.

To republish manually:

**Actions → Deploy VERA → Run workflow**

## Important limitation

The deployment workflow publishes code already present in GitHub. It does not allow ChatGPT in this conversation to edit the repository, because this chat has no authenticated GitHub connector.

For a future spoken “deploy” command to edit and publish code, one of these must be connected:

- an authenticated GitHub app/connector that can create commits or pull requests; or
- a secured backend endpoint authorized to receive approved files and call the GitHub API.

Do not place GitHub tokens, medical information, victim evidence, WhatsApp credentials, or API secrets in the public repository or GitHub Pages frontend.
